import { Link } from 'react-router-dom';
import { Twitter, Linkedin, Github } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-neo-black text-white border-t-3 border-neo-black pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link to="/" className="bg-white inline-block p-2 border-3 border-white hover:scale-105 transition-transform duration-200">
              <img src="/logo.svg" alt="Kognit" className="h-10 w-auto" style={{ minWidth: '120px', objectFit: 'contain' }} />
            </Link>
            <p className="text-gray-300 font-sans font-bold text-lg">
              The marketing automation platform for teams that want to move fast and break records.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-3 bg-white text-neo-black border-3 border-white hover:bg-electric-blue hover:text-white hover:border-electric-blue transition-colors shadow-[4px_4px_0px_0px_#FFD700]">
                <Twitter size={24} strokeWidth={2.5} />
              </a>
              <a href="#" className="p-3 bg-white text-neo-black border-3 border-white hover:bg-hot-pink hover:text-white hover:border-hot-pink transition-colors shadow-[4px_4px_0px_0px_#0055FF]">
                <Linkedin size={24} strokeWidth={2.5} />
              </a>
              <a href="#" className="p-3 bg-white text-neo-black border-3 border-white hover:bg-vivid-yellow hover:text-neo-black hover:border-vivid-yellow transition-colors shadow-[4px_4px_0px_0px_#FF0066]">
                <Github size={24} strokeWidth={2.5} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-display text-2xl font-black mb-6 text-vivid-yellow uppercase">Product</h4>
            <ul className="space-y-4 font-sans font-bold text-lg">
              <li><Link to="/features" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Features</Link></li>
              <li><Link to="/pricing" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Pricing</Link></li>
              <li><a href="#" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Integrations</a></li>
              <li><a href="#" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Changelog</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-2xl font-black mb-6 text-hot-pink uppercase">Company</h4>
            <ul className="space-y-4 font-sans font-bold text-lg">
              <li><Link to="/about" className="hover:text-hot-pink hover:underline decoration-3 underline-offset-4 transition-all">About Us</Link></li>
              <li><a href="#" className="hover:text-hot-pink hover:underline decoration-3 underline-offset-4 transition-all">Careers</a></li>
              <li><a href="#" className="hover:text-hot-pink hover:underline decoration-3 underline-offset-4 transition-all">Blog</a></li>
              <li><a href="#" className="hover:text-hot-pink hover:underline decoration-3 underline-offset-4 transition-all">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-2xl font-black mb-6 text-electric-blue uppercase">Legal</h4>
            <ul className="space-y-4 font-sans font-bold text-lg">
              <li><Link to="/terms" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Terms of Service</Link></li>
              <li><Link to="/privacy" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Privacy Policy</Link></li>
              <li><Link to="/cookie" className="hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all">Cookie Policy</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t-3 border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 font-sans font-bold mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Kognit Inc. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
