import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, hash: string) => {
    if (location.pathname === '/') {
      e.preventDefault();
      const element = document.getElementById(hash.replace('#', ''));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        window.history.pushState(null, '', `/${hash}`);
      }
    }
    setIsOpen(false);
  };

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-300 bg-white border-b-3 border-neo-black ${scrolled ? 'py-2 shadow-[0_4px_0_0_#0A0A0A]' : 'py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 hover:scale-105 hover:-rotate-2 transition-transform duration-300 block">
              <img src="/logo.svg" alt="Kognit" className="h-10 w-auto" />
            </Link>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/features" className="text-neo-black hover:text-electric-blue font-display font-bold text-xl uppercase hover:underline decoration-3 underline-offset-4 transition-all duration-200">Features</Link>
            <Link to="/pricing" className="text-neo-black hover:text-hot-pink font-display font-bold text-xl uppercase hover:underline decoration-3 underline-offset-4 transition-all duration-200">Pricing</Link>
            <Link to="/about" className="text-neo-black hover:text-vivid-yellow font-display font-bold text-xl uppercase hover:underline decoration-3 underline-offset-4 transition-all duration-200" style={{ textShadow: '1px 1px 0 #000' }}>About</Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link to="/signin" className="font-display font-bold text-xl uppercase hover:text-hot-pink hover:underline decoration-3 underline-offset-4 transition-colors duration-200">Sign In</Link>
            <Link to="/signup" className="neo-button py-2 px-5 text-lg">Get Started</Link>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-neo-black p-2 border-3 border-neo-black bg-vivid-yellow shadow-[2px_2px_0px_0px_rgba(10,10,10,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all duration-150 focus:outline-none">
              <motion.div
                initial={false}
                animate={{ rotate: isOpen ? 90 : 0 }}
                transition={{ duration: 0.2 }}
              >
                {isOpen ? <X size={28} strokeWidth={3} /> : <Menu size={28} strokeWidth={3} />}
              </motion.div>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="md:hidden bg-white border-b-3 border-neo-black absolute w-full shadow-[0_8px_0_0_#0A0A0A] overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              <Link to="/features" onClick={() => setIsOpen(false)} className="block px-3 py-4 font-display text-2xl font-bold uppercase border-b-3 border-neo-black hover:bg-electric-blue hover:text-white transition-colors duration-200">Features</Link>
              <Link to="/pricing" onClick={() => setIsOpen(false)} className="block px-3 py-4 font-display text-2xl font-bold uppercase border-b-3 border-neo-black hover:bg-hot-pink hover:text-white transition-colors duration-200">Pricing</Link>
              <Link to="/about" onClick={() => setIsOpen(false)} className="block px-3 py-4 font-display text-2xl font-bold uppercase border-b-3 border-neo-black hover:bg-vivid-yellow transition-colors duration-200">About</Link>
              <div className="pt-6 flex flex-col space-y-4 px-3">
                <Link to="/signin" onClick={() => setIsOpen(false)} className="neo-button-secondary w-full text-center">Sign In</Link>
                <Link to="/signup" onClick={() => setIsOpen(false)} className="neo-button w-full text-center">Get Started</Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
