import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function SignIn() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(false);
    
    setTimeout(() => {
      setIsLoading(false);
      setError(true);
    }, 3000);
  };

  return (
    <div className="min-h-screen flex bg-off-white">
      {/* Left side - Form */}
      <div className="w-full lg:w-1/2 flex flex-col p-8 md:p-12 lg:p-24 justify-center relative border-r-4 border-neo-black z-10 bg-white">
        <Link to="/" className="absolute top-8 left-8 md:top-12 md:left-12 flex items-center font-display font-black text-xl hover:text-electric-blue hover:underline decoration-3 underline-offset-4 transition-all uppercase group">
          <ArrowLeft className="mr-2 group-hover:-translate-x-1 transition-transform" strokeWidth={3} /> Back
        </Link>
        
        <div className="max-w-md w-full mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mb-12"
          >
            <div className="bg-vivid-yellow inline-block p-3 border-3 border-neo-black shadow-[4px_4px_0_0_#000] mb-8 transform -rotate-2 hover:rotate-0 transition-transform duration-300">
              <img src="/logo.svg" alt="Kognit" className="h-10" />
            </div>
            <h1 className="text-6xl font-display font-black uppercase mb-4 leading-none">Log In</h1>
            <p className="font-sans font-bold text-xl text-gray-600 border-l-4 border-hot-pink pl-4">Access your Kognit dashboard.</p>
          </motion.div>

          <AnimatePresence>
            {error && (
              <motion.div 
                initial={{ opacity: 0, height: 0, scale: 0.95 }}
                animate={{ opacity: 1, height: 'auto', scale: 1 }}
                exit={{ opacity: 0, height: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="mb-8 overflow-hidden"
              >
                <div className="p-6 bg-white border-4 border-red-500 flex items-start shadow-[8px_8px_0_0_#ef4444] transform rotate-1">
                  <AlertTriangle className="text-red-500 mr-4 mt-1 flex-shrink-0" size={32} strokeWidth={3} />
                  <div>
                    <h3 className="font-display font-black text-2xl text-red-600 uppercase">High Traffic Alert</h3>
                    <p className="font-sans font-bold text-lg text-neo-black mt-2">Our servers are currently experiencing unusually high traffic. Please try again in a few minutes.</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <motion.form 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            onSubmit={handleSubmit} 
            className="space-y-8"
          >
            <div className="bg-gray-50 p-6 border-3 border-neo-black shadow-[6px_6px_0_0_#000] hover:shadow-[8px_8px_0_0_#000] hover:-translate-y-1 transition-all duration-300">
              <div className="space-y-6">
                <div>
                  <label className="block font-display font-black text-xl mb-2 uppercase" htmlFor="email">Email Address</label>
                  <input 
                    id="email" 
                    type="email" 
                    required 
                    className="neo-input" 
                    placeholder="you@company.com" 
                    disabled={isLoading}
                  />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block font-display font-black text-xl uppercase" htmlFor="password">Password</label>
                    <a href="#" className="font-sans font-bold text-lg text-electric-blue hover:underline decoration-2 underline-offset-2 transition-all">Forgot?</a>
                  </div>
                  <input 
                    id="password" 
                    type="password" 
                    required 
                    className="neo-input" 
                    placeholder="••••••••" 
                    disabled={isLoading}
                  />
                </div>
              </div>
            </div>

            <button 
              type="submit" 
              className="neo-button w-full bg-electric-blue text-white hover:bg-neo-black justify-center py-5 text-2xl uppercase relative overflow-hidden group"
              disabled={isLoading}
            >
              {isLoading ? (
                <><Loader2 className="animate-spin mr-3" size={28} /> Authenticating...</>
              ) : (
                <>
                  <span className="relative z-10">Enter Dashboard</span>
                  <div className="absolute inset-0 bg-neo-black transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
                </>
              )}
            </button>
            
            <button 
              type="button" 
              className="neo-button-secondary w-full justify-center py-4 text-xl uppercase mt-4"
              disabled={isLoading}
            >
              <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google" className="h-6 w-6 mr-3" />
              Sign in with Google
            </button>
          </motion.form>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            className="mt-12 p-6 border-3 border-neo-black bg-off-white text-center shadow-[4px_4px_0_0_#000] hover:bg-vivid-yellow transition-colors duration-300"
          >
            <p className="font-sans font-bold text-xl text-neo-black">
              No account yet? <br/>
              <Link to="/signup" className="text-hot-pink font-black uppercase text-2xl hover:underline decoration-3 underline-offset-4 inline-block mt-2 transition-all">Sign up for free</Link>
            </p>
          </motion.div>
        </div>
      </div>

      {/* Right side - Visual */}
      <div className="hidden lg:flex w-1/2 bg-hot-pink relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#000 4px, transparent 4px)', backgroundSize: '40px 40px' }}></div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 100, damping: 20 }}
          className="relative z-10 max-w-lg w-full"
        >
          <div className="bg-white border-4 border-neo-black p-10 shadow-[16px_16px_0_0_#000] transform -rotate-3 hover:rotate-0 transition-transform duration-500">
            <div className="flex items-center gap-3 border-b-4 border-neo-black pb-6 mb-8">
              <div className="w-6 h-6 rounded-full bg-hot-pink border-3 border-neo-black"></div>
              <div className="w-6 h-6 rounded-full bg-vivid-yellow border-3 border-neo-black"></div>
              <div className="w-6 h-6 rounded-full bg-electric-blue border-3 border-neo-black"></div>
            </div>
            <h3 className="text-4xl font-display font-black uppercase mb-6 leading-tight">"Kognit changed everything."</h3>
            <p className="font-sans font-bold text-2xl text-gray-700 mb-10 leading-relaxed border-l-4 border-vivid-yellow pl-6">
              "We switched from a legacy provider and saw our open rates jump 40% in the first month. The visual builder is incredibly intuitive."
            </p>
            <div className="flex items-center gap-6 bg-off-white p-4 border-3 border-neo-black inline-flex hover:bg-vivid-yellow transition-colors duration-300">
              <img src="https://i.pravatar.cc/150?img=32" alt="Sarah J." className="w-20 h-20 rounded-full border-3 border-neo-black object-cover" />
              <div>
                <div className="font-display font-black text-2xl uppercase">Sarah Jenkins</div>
                <div className="font-sans font-bold text-xl text-electric-blue">CMO at TechFlow</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
