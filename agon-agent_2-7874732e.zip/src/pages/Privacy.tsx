export default function Privacy() {
  return (
    <div className="pt-20 pb-32 bg-off-white min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl md:text-7xl font-display font-black uppercase mb-12">Privacy Policy</h1>
        
        <div className="bg-neo-black text-white neo-border p-8 shadow-[8px_8px_0_0_#FF0066] prose prose-lg prose-invert font-sans">
          <p className="font-bold text-xl mb-8 border-b-2 border-gray-700 pb-4 text-hot-pink">We respect your data. Period.</p>
          
          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase text-white">1. Information We Collect</h2>
          <p>We only collect information that helps us provide you with the best possible service. This includes:</p>
          <ul className="list-disc pl-6 space-y-2 font-medium text-gray-300">
            <li>Account information (name, email, password)</li>
            <li>Billing details (processed securely via Stripe)</li>
            <li>Usage data (how you interact with our platform)</li>
          </ul>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase text-white">2. How We Use Your Data</h2>
          <p>We use your data to:</p>
          <ul className="list-disc pl-6 space-y-2 font-medium text-gray-300">
            <li>Provide and maintain our service</li>
            <li>Notify you about changes to our service</li>
            <li>Provide customer support</li>
            <li>Monitor the usage of our service</li>
          </ul>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase text-white">3. Data Security</h2>
          <p>We use industry-standard encryption to protect your data. However, no method of transmission over the Internet, or method of electronic storage is 100% secure. We strive to use commercially acceptable means to protect your Personal Data, but cannot guarantee its absolute security.</p>
        </div>
      </div>
    </div>
  );
}
