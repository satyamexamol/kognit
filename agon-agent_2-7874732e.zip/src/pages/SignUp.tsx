import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Loader2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function SignUp() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(false);
    
    setTimeout(() => {
      setIsLoading(false);
      setError(true);
    }, 3000);
  };

  return (
    <div className="min-h-screen flex bg-off-white">
      {/* Left side - Visual */}
      <div className="hidden lg:flex w-1/2 bg-electric-blue border-r-4 border-neo-black relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'repeating-linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000), repeating-linear-gradient(45deg, #000 25%, #fff 25%, #fff 75%, #000 75%, #000)', backgroundPosition: '0 0, 20px 20px', backgroundSize: '40px 40px' }}></div>
        
        <div className="relative z-10 max-w-lg w-full">
          <motion.div 
            initial={{ opacity: 0, x: -50, rotate: -5 }}
            animate={{ opacity: 1, x: 0, rotate: 2 }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
            className="bg-vivid-yellow border-4 border-neo-black p-10 shadow-[16px_16px_0_0_#000] hover:rotate-0 transition-transform duration-500"
          >
            <h2 className="text-6xl font-display font-black uppercase mb-10 leading-none" style={{ textShadow: '4px 4px 0 #fff' }}>
              Start your <br/>14-day trial
            </h2>
            
            <ul className="space-y-6">
              {[
                'Full access to all Scale features',
                'No credit card required',
                'Cancel anytime, no questions asked',
                'Free onboarding call with an expert'
              ].map((item, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 + 0.3 }}
                  className="flex items-center font-sans font-bold text-2xl bg-white p-4 border-3 border-neo-black shadow-[6px_6px_0_0_#000] hover:-translate-y-1 hover:shadow-[8px_8px_0_0_#000] transition-all duration-300"
                >
                  <CheckCircle2 className="text-hot-pink mr-4 flex-shrink-0" size={32} strokeWidth={3} />
                  {item}
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="w-full lg:w-1/2 flex flex-col p-8 md:p-12 lg:p-24 justify-center relative bg-white">
        <Link to="/" className="absolute top-8 right-8 md:top-12 md:right-12 flex items-center font-display font-black text-xl hover:text-hot-pink hover:underline decoration-3 underline-offset-4 transition-all uppercase lg:hidden group">
          Back <ArrowLeft className="ml-2 rotate-180 group-hover:translate-x-1 transition-transform" strokeWidth={3} />
        </Link>
        
        <div className="max-w-md w-full mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mb-10"
          >
            <div className="bg-hot-pink inline-block p-3 border-3 border-neo-black shadow-[4px_4px_0_0_#000] mb-8 transform rotate-2 lg:hidden">
              <img src="/logo.svg" alt="Kognit" className="h-10 filter invert" />
            </div>
            <h1 className="text-6xl font-display font-black uppercase mb-4 leading-none">Sign Up</h1>
            <p className="font-sans font-bold text-xl text-gray-600 border-l-4 border-electric-blue pl-4">Join 10,000+ marketers dominating their funnels.</p>
          </motion.div>

          <AnimatePresence>
            {error && (
              <motion.div 
                initial={{ opacity: 0, height: 0, scale: 0.95 }}
                animate={{ opacity: 1, height: 'auto', scale: 1 }}
                exit={{ opacity: 0, height: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="mb-8 overflow-hidden"
              >
                <div className="p-6 bg-white border-4 border-red-500 flex items-start shadow-[8px_8px_0_0_#ef4444] transform -rotate-1">
                  <AlertTriangle className="text-red-500 mr-4 mt-1 flex-shrink-0" size={32} strokeWidth={3} />
                  <div>
                    <h3 className="font-display font-black text-2xl text-red-600 uppercase">High Traffic Alert</h3>
                    <p className="font-sans font-bold text-lg text-neo-black mt-2">Our servers are processing a high volume of new signups. Please try again in a few minutes.</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <motion.form 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            onSubmit={handleSubmit} 
            className="space-y-6"
          >
            <div className="bg-off-white p-6 border-3 border-neo-black shadow-[6px_6px_0_0_#000] hover:shadow-[8px_8px_0_0_#000] hover:-translate-y-1 transition-all duration-300">
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-display font-black text-lg mb-2 uppercase" htmlFor="firstName">First Name</label>
                    <input id="firstName" type="text" required className="neo-input" placeholder="Jane" disabled={isLoading} />
                  </div>
                  <div>
                    <label className="block font-display font-black text-lg mb-2 uppercase" htmlFor="lastName">Last Name</label>
                    <input id="lastName" type="text" required className="neo-input" placeholder="Doe" disabled={isLoading} />
                  </div>
                </div>

                <div>
                  <label className="block font-display font-black text-lg mb-2 uppercase" htmlFor="company">Company</label>
                  <input id="company" type="text" required className="neo-input" placeholder="Acme Corp" disabled={isLoading} />
                </div>
                
                <div>
                  <label className="block font-display font-black text-lg mb-2 uppercase" htmlFor="email">Work Email</label>
                  <input id="email" type="email" required className="neo-input" placeholder="jane@acmecorp.com" disabled={isLoading} />
                </div>
                
                <div>
                  <label className="block font-display font-black text-lg mb-2 uppercase" htmlFor="password">Password</label>
                  <input id="password" type="password" required className="neo-input" placeholder="••••••••" disabled={isLoading} />
                  <p className="text-sm font-sans font-bold text-gray-500 mt-2 bg-white inline-block px-2 border-2 border-neo-black">Min 8 characters</p>
                </div>
              </div>
            </div>

            <button 
              type="submit" 
              className="neo-button w-full bg-vivid-yellow text-neo-black hover:bg-hot-pink hover:text-white justify-center py-5 text-2xl uppercase mt-8 relative overflow-hidden group"
              disabled={isLoading}
            >
              {isLoading ? (
                <><Loader2 className="animate-spin mr-3" size={28} /> Creating...</>
              ) : (
                <>
                  <span className="relative z-10 transition-colors duration-300">Start Free Trial</span>
                  <div className="absolute inset-0 bg-hot-pink transform scale-y-0 group-hover:scale-y-100 transition-transform duration-300 origin-bottom"></div>
                </>
              )}
            </button>
          </motion.form>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 0.2 }}
            className="mt-10 space-y-4 text-center"
          >
            <p className="font-sans font-bold text-sm text-gray-600 bg-gray-100 p-3 border-2 border-neo-black inline-block hover:bg-white transition-colors duration-300">
              By signing up, you agree to our <Link to="/terms" className="text-neo-black font-black hover:underline uppercase transition-all">Terms</Link> and <Link to="/privacy" className="text-neo-black font-black hover:underline uppercase transition-all">Privacy</Link>.
            </p>
            
            <p className="font-sans font-bold text-xl text-neo-black pt-4">
              Already have an account? <Link to="/signin" className="text-electric-blue font-black uppercase hover:underline decoration-3 underline-offset-4 transition-all">Log in</Link>
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
