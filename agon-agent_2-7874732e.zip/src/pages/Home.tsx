import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Zap, Users, BarChart3, Star, CheckCircle2, ChevronDown, Play, Plus, ArrowRight, RefreshCw, Layers, MessageSquare, ShoppingCart, Cloud, Share2, CreditCard, Hash, Headphones, MessageCircle, Layout, PieChart, HelpCircle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

const data = [
  { name: 'Mon', email: 4000, sms: 2400 },
  { name: 'Tue', email: 3000, sms: 1398 },
  { name: 'Wed', email: 2000, sms: 9800 },
  { name: 'Thu', email: 2780, sms: 3908 },
  { name: 'Fri', email: 1890, sms: 4800 },
  { name: 'Sat', email: 2390, sms: 3800 },
  { name: 'Sun', email: 3490, sms: 4300 },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring' as const, stiffness: 100, damping: 15 }
  }
};

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden border-b-3 border-neo-black bg-vivid-yellow">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#000 3px, transparent 3px)', backgroundSize: '32px 32px' }}></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={containerVariants}
              className="space-y-8"
            >
              <motion.div variants={itemVariants} className="neo-badge bg-white text-electric-blue">
                <Zap size={16} className="mr-2 fill-current" /> Kognit 2.0 is Live
              </motion.div>
              
              <motion.h1 variants={itemVariants} className="text-6xl md:text-8xl font-display font-black leading-none tracking-tighter uppercase" style={{ textShadow: '4px 4px 0px #fff' }}>
                Automate <br/>
                <span className="text-electric-blue" style={{ textShadow: '4px 4px 0px #000' }}>Like a Pro.</span>
              </motion.h1>
              
              <motion.p variants={itemVariants} className="text-2xl font-sans font-bold text-neo-black max-w-lg leading-relaxed bg-white/90 inline-block p-3 border-3 border-neo-black shadow-[4px_4px_0_0_#000]">
                Build visual workflows, segment users dynamically, and send personalized campaigns. No coding required.
              </motion.p>
              
              <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-6 pt-4">
                <Link to="/signup" className="neo-button-primary text-xl py-4 px-8 w-full sm:w-auto">
                  Start Free Trial <ArrowRight className="ml-2" strokeWidth={3} />
                </Link>
                <Link to="/features" className="neo-button-secondary text-xl py-4 px-8 w-full sm:w-auto">
                  <Play className="mr-2" strokeWidth={3} /> Explore Features
                </Link>
              </motion.div>
            </motion.div>

            {/* Dashboard Mockup */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, rotate: -2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 100, damping: 20, delay: 0.2 }}
              className="relative mt-12 lg:mt-0 w-full max-w-full overflow-visible px-4 sm:px-0"
            >
              <div className="absolute inset-0 bg-hot-pink translate-x-4 translate-y-4 sm:translate-x-6 sm:translate-y-6 border-3 border-neo-black"></div>
              <div className="absolute inset-0 bg-electric-blue translate-x-2 translate-y-2 sm:translate-x-3 sm:translate-y-3 border-3 border-neo-black"></div>
              <div className="relative bg-white border-3 border-neo-black h-[400px] sm:h-[500px] flex flex-col shadow-neo-lg group hover:-translate-y-1 hover:-translate-x-1 sm:hover:-translate-y-2 sm:hover:-translate-x-2 hover:shadow-[8px_8px_0_0_#000] sm:hover:shadow-[12px_12px_0_0_#000] transition-all duration-300 overflow-hidden">
                <div className="flex items-center gap-2 border-b-3 border-neo-black px-3 py-2 sm:px-4 sm:py-3 bg-gray-100 flex-shrink-0">
                  <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-hot-pink border-2 border-neo-black"></div>
                  <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-vivid-yellow border-2 border-neo-black"></div>
                  <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-electric-blue border-2 border-neo-black"></div>
                  <div className="ml-2 sm:ml-4 font-display font-bold text-xs sm:text-sm tracking-widest uppercase truncate">Kognit Dashboard</div>
                </div>
                
                <div className="p-3 sm:p-6 grid grid-cols-3 gap-2 sm:gap-4 border-b-3 border-neo-black bg-white flex-shrink-0">
                  <div className="bg-blue-50 border-2 sm:border-3 border-neo-black p-2 sm:p-4 shadow-[2px_2px_0_0_#000] sm:shadow-[4px_4px_0_0_#000]">
                    <div className="text-xs sm:text-sm font-bold text-gray-600 uppercase truncate">Open Rate</div>
                    <div className="text-xl sm:text-3xl font-display font-black text-electric-blue">64.2%</div>
                  </div>
                  <div className="bg-pink-50 border-2 sm:border-3 border-neo-black p-2 sm:p-4 shadow-[2px_2px_0_0_#000] sm:shadow-[4px_4px_0_0_#000]">
                    <div className="text-xs sm:text-sm font-bold text-gray-600 uppercase truncate">Click Rate</div>
                    <div className="text-xl sm:text-3xl font-display font-black text-hot-pink">28.5%</div>
                  </div>
                  <div className="bg-yellow-50 border-2 sm:border-3 border-neo-black p-2 sm:p-4 shadow-[2px_2px_0_0_#000] sm:shadow-[4px_4px_0_0_#000]">
                    <div className="text-xs sm:text-sm font-bold text-gray-600 uppercase truncate">Conversion</div>
                    <div className="text-xl sm:text-3xl font-display font-black text-yellow-600">12.4%</div>
                  </div>
                </div>
                
                <div className="flex-grow p-3 sm:p-6 bg-off-white min-h-0">
                  <div className="h-full w-full border-2 sm:border-3 border-neo-black bg-white p-2 sm:p-4 shadow-[2px_2px_0_0_#000] sm:shadow-[4px_4px_0_0_#000]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={data} margin={{ top: 10, right: 0, left: -30, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="0" stroke="#000" vertical={false} strokeWidth={2} />
                        <XAxis dataKey="name" stroke="#000" tick={{fontFamily: 'Satoshi', fontWeight: 900, fontSize: 10}} tickLine={{stroke: '#000', strokeWidth: 2}} axisLine={{stroke: '#000', strokeWidth: 2}} />
                        <YAxis stroke="#000" tick={{fontFamily: 'Satoshi', fontWeight: 900, fontSize: 10}} tickLine={{stroke: '#000', strokeWidth: 2}} axisLine={{stroke: '#000', strokeWidth: 2}} width={40} />
                        <Tooltip contentStyle={{ border: '3px solid #000', borderRadius: 0, boxShadow: '4px 4px 0 #000', fontFamily: 'Satoshi', fontWeight: 700, fontSize: '12px', padding: '8px' }} />
                        <Area type="step" dataKey="email" stackId="1" stroke="#0055FF" fill="#0055FF" strokeWidth={3} />
                        <Area type="step" dataKey="sms" stackId="1" stroke="#FF0066" fill="#FF0066" strokeWidth={3} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Logos */}
      <section className="py-12 border-b-3 border-neo-black bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center font-display font-black text-xl mb-8 uppercase tracking-widest">Trusted by Disruptive Brands</p>
          <div className="flex justify-between items-center flex-wrap gap-8">
            {['Acme Corp', 'GlobalTech', 'Nexus', 'Stark Ind', 'Wayne Ent', 'CyberDyne'].map((logo, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-2xl md:text-3xl font-display font-black tracking-widest uppercase hover:text-hot-pink transition-colors cursor-default"
              >
                {logo}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-off-white border-b-3 border-neo-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
            className="text-center max-w-4xl mx-auto mb-20"
          >
            <motion.div variants={itemVariants} className="neo-badge bg-hot-pink text-white mb-6">Features</motion.div>
            <motion.h2 variants={itemVariants} className="text-5xl md:text-7xl font-display font-black uppercase mb-6 leading-none">Everything you need <br/>to <span className="text-electric-blue" style={{ textShadow: '4px 4px 0 #000' }}>dominate</span></motion.h2>
            <motion.p variants={itemVariants} className="text-2xl font-sans font-bold text-gray-700 border-l-4 border-neo-black pl-6 text-left">Stop juggling multiple tools. Kognit provides a unified platform for all your marketing automation needs.</motion.p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: <Mail size={40} strokeWidth={2.5} />, title: "Email Campaigns", desc: "Drag-and-drop builder with high-converting templates.", color: "bg-electric-blue" },
              { icon: <Zap size={40} strokeWidth={2.5} />, title: "Visual Workflows", desc: "If-this-then-that logic made simple and visual.", color: "bg-hot-pink" },
              { icon: <Users size={40} strokeWidth={2.5} />, title: "Deep Segmentation", desc: "Target users based on behavior, not just demographics.", color: "bg-vivid-yellow" },
              { icon: <BarChart3 size={40} strokeWidth={2.5} />, title: "Real-time Analytics", desc: "See exactly what's working and what's not instantly.", color: "bg-green-400" },
              { icon: <Star size={40} strokeWidth={2.5} />, title: "A/B Testing", desc: "Test subject lines, content, and send times.", color: "bg-purple-400" },
              { icon: <CheckCircle2 size={40} strokeWidth={2.5} />, title: "Deliverability", desc: "Dedicated IP options and automated list cleaning.", color: "bg-orange-400" }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: i * 0.1, type: "spring", stiffness: 100 }}
                className="neo-card flex flex-col items-start group"
              >
                <div className={`p-4 border-3 border-neo-black ${feature.color} text-neo-black mb-6 shadow-[4px_4px_0_0_#000] group-hover:-rotate-6 transition-transform duration-300`}>
                  {feature.icon}
                </div>
                <h3 className="text-3xl font-display font-black mb-4 uppercase">{feature.title}</h3>
                <p className="font-sans text-xl font-bold text-gray-700 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-white border-b-3 border-neo-black overflow-hidden relative">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', backgroundSize: '24px 24px' }}></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
            className="text-center max-w-4xl mx-auto mb-20"
          >
            <motion.div variants={itemVariants} className="neo-badge bg-vivid-yellow text-neo-black mb-6">Workflow</motion.div>
            <motion.h2 variants={itemVariants} className="text-5xl md:text-7xl font-display font-black uppercase mb-6 leading-none">Connect. Build. <span className="text-hot-pink" style={{ textShadow: '4px 4px 0 #000' }}>Convert.</span></motion.h2>
          </motion.div>

          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            variants={containerVariants}
            className="grid md:grid-cols-3 gap-8 relative"
          >
            {/* Connecting line for desktop */}
            <div className="hidden md:block absolute top-[4rem] left-0 w-full h-2 bg-neo-black z-0"></div>
            
            {[
              { step: "01", title: "Sync Data", desc: "Connect your CRM and pull in customer data instantly.", color: "bg-electric-blue", icon: <RefreshCw size={32} strokeWidth={3} /> },
              { step: "02", title: "Build Logic", desc: "Use the visual canvas to map out user journeys.", color: "bg-hot-pink", icon: <Layers size={32} strokeWidth={3} /> },
              { step: "03", title: "Go Live", desc: "Launch campaigns and watch the analytics roll in.", color: "bg-vivid-yellow", icon: <MessageSquare size={32} strokeWidth={3} /> }
            ].map((s, i) => (
              <motion.div key={i} variants={itemVariants} className="relative z-10 bg-white border-3 border-neo-black p-8 shadow-[8px_8px_0_0_#000] hover:-translate-y-2 transition-transform duration-300 mt-8 md:mt-0">
                <div className={`w-16 h-16 ${s.color} border-3 border-neo-black flex items-center justify-center mb-6 shadow-[4px_4px_0_0_#000] text-white mx-auto md:mx-0`}>
                  {s.step === "03" ? <span className="text-neo-black">{s.icon}</span> : s.icon}
                </div>
                <h3 className="text-3xl font-display font-black uppercase mb-4 text-center md:text-left">{s.title}</h3>
                <p className="font-sans text-xl font-bold text-gray-700 text-center md:text-left">{s.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-hot-pink border-b-3 border-neo-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="text-center mb-20"
          >
            <motion.h2 variants={itemVariants} className="text-5xl md:text-7xl font-display font-black uppercase text-white" style={{ textShadow: '4px 4px 0 #000' }}>Wall of Love</motion.h2>
          </motion.div>
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="grid md:grid-cols-3 gap-8"
          >
            {[
              { quote: "Kognit is the first marketing tool that doesn't make me want to pull my hair out.", author: "Jane D.", role: "Growth Lead", img: "45" },
              { quote: "We migrated from a legacy enterprise tool in 2 days. The speed is unmatched.", author: "Mike T.", role: "CTO", img: "12" },
              { quote: "Our open rates doubled just by using the smart delivery features. Insane ROI.", author: "Sarah W.", role: "Founder", img: "32" }
            ].map((t, i) => (
              <motion.div key={i} variants={itemVariants} className="bg-off-white border-3 border-neo-black p-8 shadow-[8px_8px_0_0_#000] flex flex-col justify-between hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[12px_12px_0_0_#000] transition-all duration-300">
                <div className="mb-8">
                  <div className="flex text-vivid-yellow mb-4 drop-shadow-[2px_2px_0_#000]">
                    {[1,2,3,4,5].map(star => <Star key={star} size={24} fill="currentColor" strokeWidth={2} stroke="#000" />)}
                  </div>
                  <p className="font-sans font-bold text-xl leading-relaxed text-neo-black">"{t.quote}"</p>
                </div>
                <div className="flex items-center gap-4">
                  <img src={`https://i.pravatar.cc/150?img=${t.img}`} alt={t.author} className="w-14 h-14 rounded-full border-3 border-neo-black" />
                  <div>
                    <div className="font-display font-black uppercase text-lg">{t.author}</div>
                    <div className="font-sans font-bold text-gray-600">{t.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24 bg-electric-blue border-b-3 border-neo-black relative">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'repeating-linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000), repeating-linear-gradient(45deg, #000 25%, #fff 25%, #fff 75%, #000 75%, #000)', backgroundPosition: '0 0, 16px 16px', backgroundSize: '32px 32px' }}></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="text-center max-w-3xl mx-auto mb-20"
          >
            <motion.div variants={itemVariants} className="neo-badge bg-vivid-yellow text-neo-black mb-6">Pricing</motion.div>
            <motion.h2 variants={itemVariants} className="text-5xl md:text-7xl font-display font-black uppercase mb-6 text-white" style={{ textShadow: '4px 4px 0 #000' }}>Simple, brutal pricing</motion.h2>
            <motion.p variants={itemVariants} className="text-2xl font-sans font-bold text-white bg-neo-black inline-block px-4 py-2 border-2 border-white">No hidden fees. Just pick what you need.</motion.p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto items-end">
            {/* Starter */}
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ type: "spring", stiffness: 100 }}
              className="bg-white border-3 border-neo-black p-8 flex flex-col shadow-[8px_8px_0_0_#000] hover:-translate-y-2 hover:shadow-[12px_12px_0_0_#000] transition-all duration-300"
            >
              <h3 className="text-4xl font-display font-black mb-2 uppercase">Hustler</h3>
              <p className="text-gray-600 font-bold text-lg mb-6">For early-stage startups</p>
              <div className="text-6xl font-display font-black mb-8">$29<span className="text-2xl text-gray-500 font-bold">/mo</span></div>
              <ul className="space-y-4 mb-8 flex-grow">
                {['Up to 5,000 contacts', 'Unlimited emails', 'Basic workflows', 'Standard support'].map((item, i) => (
                  <li key={i} className="flex items-center font-sans font-bold text-lg">
                    <CheckCircle2 className="text-hot-pink mr-3 flex-shrink-0" size={24} strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/signup" className="neo-button-secondary w-full text-xl">Start Free</Link>
            </motion.div>

            {/* Pro */}
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ type: "spring", stiffness: 100, delay: 0.1 }}
              className="bg-neo-black text-white border-3 border-white p-8 flex flex-col shadow-[12px_12px_0_0_#FFD700] relative transform md:-translate-y-8 hover:-translate-y-10 transition-transform duration-300 z-10"
            >
              <div className="absolute top-0 right-0 bg-vivid-yellow text-neo-black font-display font-black text-sm px-4 py-2 border-b-3 border-l-3 border-white uppercase tracking-widest">MOST POPULAR</div>
              <h3 className="text-4xl font-display font-black mb-2 text-vivid-yellow uppercase">Scale</h3>
              <p className="text-gray-400 font-bold text-lg mb-6">For growing businesses</p>
              <div className="text-6xl font-display font-black mb-8">$99<span className="text-2xl text-gray-400 font-bold">/mo</span></div>
              <ul className="space-y-4 mb-8 flex-grow">
                {['Up to 25,000 contacts', 'Advanced workflows', 'A/B Testing', 'Custom domains', 'Priority support'].map((item, i) => (
                  <li key={i} className="flex items-center font-sans font-bold text-lg">
                    <CheckCircle2 className="text-vivid-yellow mr-3 flex-shrink-0" size={24} strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/signup" className="neo-button bg-hot-pink text-white hover:bg-white hover:text-neo-black w-full text-xl border-white hover:border-neo-black">Get Scale</Link>
            </motion.div>

            {/* Enterprise */}
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ type: "spring", stiffness: 100, delay: 0.2 }}
              className="bg-white border-3 border-neo-black p-8 flex flex-col shadow-[8px_8px_0_0_#000] hover:-translate-y-2 hover:shadow-[12px_12px_0_0_#000] transition-all duration-300"
            >
              <h3 className="text-4xl font-display font-black mb-2 uppercase">Empire</h3>
              <p className="text-gray-600 font-bold text-lg mb-6">For large organizations</p>
              <div className="text-6xl font-display font-black mb-8">$299<span className="text-2xl text-gray-500 font-bold">/mo</span></div>
              <ul className="space-y-4 mb-8 flex-grow">
                {['Unlimited contacts', 'Custom integrations', 'Dedicated IP', 'SAML SSO', '24/7 Phone support'].map((item, i) => (
                  <li key={i} className="flex items-center font-sans font-bold text-lg">
                    <CheckCircle2 className="text-electric-blue mr-3 flex-shrink-0" size={24} strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/about" className="neo-button-secondary w-full text-xl">Contact Sales</Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Integrations */}
      <section className="py-24 bg-neo-black border-b-3 border-neo-black text-white overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
            className="grid lg:grid-cols-2 gap-16 items-center"
          >
            <div>
              <motion.div variants={itemVariants} className="neo-badge bg-electric-blue text-white border-white mb-6">Integrations</motion.div>
              <motion.h2 variants={itemVariants} className="text-5xl md:text-7xl font-display font-black uppercase mb-6" style={{ textShadow: '4px 4px 0 #0055FF' }}>Plays nice <br/>with others</motion.h2>
              <motion.p variants={itemVariants} className="text-2xl font-sans font-bold text-gray-300 mb-8 border-l-4 border-hot-pink pl-6">
                Connect Kognit to your existing stack in one click. We push and pull data seamlessly so you can focus on building.
              </motion.p>
              <motion.div variants={itemVariants}>
                <Link to="/features" className="neo-button bg-white text-neo-black hover:bg-vivid-yellow border-white hover:border-neo-black">
                  View All Integrations
                </Link>
              </motion.div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                { name: 'Shopify', icon: <ShoppingCart size={28} strokeWidth={2.5} /> },
                { name: 'Salesforce', icon: <Cloud size={28} strokeWidth={2.5} /> },
                { name: 'HubSpot', icon: <Share2 size={28} strokeWidth={2.5} /> },
                { name: 'Stripe', icon: <CreditCard size={28} strokeWidth={2.5} /> },
                { name: 'Slack', icon: <Hash size={28} strokeWidth={2.5} /> },
                { name: 'Zendesk', icon: <Headphones size={28} strokeWidth={2.5} /> },
                { name: 'Intercom', icon: <MessageCircle size={28} strokeWidth={2.5} /> },
                { name: 'Webflow', icon: <Layout size={28} strokeWidth={2.5} /> },
                { name: 'Segment', icon: <PieChart size={28} strokeWidth={2.5} /> }
              ].map((brand, i) => (
                <motion.div 
                  key={i} 
                  variants={itemVariants} 
                  className="bg-white text-neo-black border-3 border-white p-4 flex flex-col items-center justify-center gap-3 text-center font-display font-black uppercase text-lg shadow-[4px_4px_0_0_#FF0066] hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[8px_8px_0_0_#FFD700] transition-all duration-200 cursor-default"
                >
                  <div className="text-electric-blue">{brand.icon}</div>
                  <span>{brand.name}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-vivid-yellow border-b-3 border-neo-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-5xl md:text-7xl font-display font-black uppercase mb-16 text-center flex items-center justify-center gap-4 flex-wrap" 
            style={{ textShadow: '4px 4px 0 #fff' }}
          >
            <HelpCircle size={56} className="text-neo-black fill-white hidden md:block" strokeWidth={2} /> Burning Questions
          </motion.h2>
          
          <div className="space-y-6">
            {[
              { q: "How long does it take to get set up?", a: "Minutes. Our visual builder and pre-made templates mean you can launch your first campaign before your coffee gets cold." },
              { q: "Can I import my existing contacts?", a: "Absolutely. Just upload a CSV or connect directly to your CRM using our native integrations." },
              { q: "Do you offer a free trial?", a: "Yes, 14 days of full access to all Scale features. No credit card required." },
              { q: "What happens if I go over my contact limit?", a: "We'll gently notify you and automatically upgrade you to the next tier at the start of your next billing cycle. No service interruptions." }
            ].map((faq, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white border-3 border-neo-black shadow-[6px_6px_0_0_#000] hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[8px_8px_0_0_#000] transition-all duration-300"
              >
                <button 
                  className="w-full px-8 py-6 flex justify-between items-center bg-white hover:bg-gray-50 text-left focus:outline-none focus:bg-vivid-yellow/20"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <span className="font-display font-black text-2xl uppercase pr-4">{faq.q}</span>
                  <motion.div
                    animate={{ rotate: openFaq === i ? 45 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Plus className={`flex-shrink-0 ${openFaq === i ? 'text-hot-pink' : 'text-neo-black'}`} size={32} strokeWidth={3} />
                  </motion.div>
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: openFaq === i ? 'auto' : 0, opacity: openFaq === i ? 1 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="px-8 py-6 border-t-3 border-neo-black font-sans font-bold text-xl bg-off-white leading-relaxed">
                    {faq.a}
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-32 bg-hot-pink text-white text-center border-b-3 border-neo-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <motion.h2 variants={itemVariants} className="text-6xl md:text-8xl font-display font-black uppercase mb-8 leading-none" style={{ textShadow: '6px 6px 0 #000' }}>
              Ready to <br/>dominate?
            </motion.h2>
            <motion.p variants={itemVariants} className="text-3xl font-sans font-bold mb-12 max-w-2xl mx-auto border-4 border-white p-6 bg-neo-black shadow-[8px_8px_0_0_#fff]">
              Stop playing catch-up. Join the thousands of marketers using Kognit to crush their goals.
            </motion.p>
            <motion.div variants={itemVariants}>
              <Link to="/signup" className="neo-button bg-vivid-yellow text-neo-black hover:bg-white text-3xl py-6 px-12 inline-flex shadow-[8px_8px_0_0_#000] border-4">
                Get Started For Free <Zap className="ml-4" size={36} strokeWidth={3} />
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
