export default function Cookie() {
  return (
    <div className="pt-20 pb-32 bg-off-white min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl md:text-7xl font-display font-black uppercase mb-12">Cookie Policy</h1>
        
        <div className="bg-white neo-border p-8 shadow-[8px_8px_0_0_#0055FF] prose prose-lg font-sans">
          <p className="font-bold text-xl mb-8 border-b-2 border-neo-black pb-4">Yes, we use cookies.</p>
          
          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">What are cookies?</h2>
          <p>Cookies are small pieces of text sent to your web browser by a website you visit. A cookie file is stored in your web browser and allows the Service or a third-party to recognize you and make your next visit easier and the Service more useful to you.</p>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">How Kognit uses cookies</h2>
          <p>When you use and access the Service, we may place a number of cookies files in your web browser. We use cookies for the following purposes:</p>
          <ul className="list-disc pl-6 space-y-2 font-medium">
            <li>To enable certain functions of the Service</li>
            <li>To provide analytics</li>
            <li>To store your preferences</li>
          </ul>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">Your choices</h2>
          <p>If you'd like to delete cookies or instruct your web browser to delete or refuse cookies, please visit the help pages of your web browser. Please note, however, that if you delete cookies or refuse to accept them, you might not be able to use all of the features we offer.</p>
        </div>
      </div>
    </div>
  );
}
