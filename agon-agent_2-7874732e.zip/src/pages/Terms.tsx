export default function Terms() {
  return (
    <div className="pt-20 pb-32 bg-off-white min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-5xl md:text-7xl font-display font-black uppercase mb-12">Terms & Conditions</h1>
        
        <div className="bg-white neo-border p-8 shadow-[8px_8px_0_0_#000] prose prose-lg font-sans">
          <p className="font-bold text-xl mb-8 border-b-2 border-neo-black pb-4">Last updated: October 24, 2023</p>
          
          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">1. Agreement to Terms</h2>
          <p>By accessing or using Kognit's services, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the service. It's that simple.</p>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">2. Use License</h2>
          <p>Permission is granted to temporarily download one copy of the materials (information or software) on Kognit's website for personal, non-commercial transitory viewing only.</p>
          <ul className="list-disc pl-6 space-y-2 font-medium">
            <li>You cannot modify or copy the materials;</li>
            <li>You cannot use the materials for any commercial purpose;</li>
            <li>You cannot attempt to decompile or reverse engineer any software;</li>
            <li>You cannot remove any copyright or other proprietary notations.</li>
          </ul>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">3. Disclaimer</h2>
          <p>The materials on Kognit's website are provided on an 'as is' basis. Kognit makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>

          <h2 className="text-3xl font-display font-bold mt-8 mb-4 uppercase">4. Limitations</h2>
          <p>In no event shall Kognit or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Kognit's website.</p>
        </div>
      </div>
    </div>
  );
}
