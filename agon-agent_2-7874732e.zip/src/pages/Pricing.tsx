import { Link } from 'react-router-dom';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Pricing() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: "spring" as const, stiffness: 100 }
    }
  };

  return (
    <div className="pt-24 min-h-screen bg-electric-blue relative">
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'repeating-linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000), repeating-linear-gradient(45deg, #000 25%, #fff 25%, #fff 75%, #000 75%, #000)', backgroundPosition: '0 0, 16px 16px', backgroundSize: '32px 32px' }}></div>
      
      <section className="py-24 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-3xl mx-auto mb-20"
          >
            <div className="neo-badge bg-vivid-yellow text-neo-black mb-6">Pricing</div>
            <h1 className="text-5xl md:text-7xl font-display font-black uppercase mb-6 text-white" style={{ textShadow: '4px 4px 0 #000' }}>Simple, brutal pricing</h1>
            <p className="text-2xl font-sans font-bold text-white bg-neo-black inline-block px-4 py-2 border-2 border-white">No hidden fees. Just pick what you need.</p>
          </motion.div>

          <motion.div 
            initial="hidden"
            animate="visible"
            variants={containerVariants}
            className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto items-end"
          >
            {/* Starter */}
            <motion.div variants={itemVariants} className="bg-white border-3 border-neo-black p-8 flex flex-col shadow-[8px_8px_0_0_#000] hover:-translate-y-2 hover:shadow-[12px_12px_0_0_#000] transition-all duration-300">
              <h3 className="text-4xl font-display font-black mb-2 uppercase">Hustler</h3>
              <p className="text-gray-600 font-bold text-lg mb-6">For early-stage startups</p>
              <div className="text-6xl font-display font-black mb-8">$29<span className="text-2xl text-gray-500 font-bold">/mo</span></div>
              <ul className="space-y-4 mb-8 flex-grow">
                {['Up to 5,000 contacts', 'Unlimited emails', 'Basic workflows', 'Standard support'].map((item, i) => (
                  <li key={i} className="flex items-center font-sans font-bold text-lg">
                    <CheckCircle2 className="text-hot-pink mr-3 flex-shrink-0" size={24} strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/signup" className="neo-button-secondary w-full text-xl">Start Free</Link>
            </motion.div>

            {/* Pro */}
            <motion.div variants={itemVariants} className="bg-neo-black text-white border-3 border-white p-8 flex flex-col shadow-[12px_12px_0_0_#FFD700] relative transform md:-translate-y-8 hover:-translate-y-10 transition-transform duration-300 z-10">
              <div className="absolute top-0 right-0 bg-vivid-yellow text-neo-black font-display font-black text-sm px-4 py-2 border-b-3 border-l-3 border-white uppercase tracking-widest">MOST POPULAR</div>
              <h3 className="text-4xl font-display font-black mb-2 text-vivid-yellow uppercase">Scale</h3>
              <p className="text-gray-400 font-bold text-lg mb-6">For growing businesses</p>
              <div className="text-6xl font-display font-black mb-8">$99<span className="text-2xl text-gray-400 font-bold">/mo</span></div>
              <ul className="space-y-4 mb-8 flex-grow">
                {['Up to 25,000 contacts', 'Advanced workflows', 'A/B Testing', 'Custom domains', 'Priority support'].map((item, i) => (
                  <li key={i} className="flex items-center font-sans font-bold text-lg">
                    <CheckCircle2 className="text-vivid-yellow mr-3 flex-shrink-0" size={24} strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/signup" className="neo-button bg-hot-pink text-white hover:bg-white hover:text-neo-black w-full text-xl border-white hover:border-neo-black relative overflow-hidden group">
                <span className="relative z-10 transition-colors duration-300">Get Scale</span>
                <div className="absolute inset-0 bg-white transform scale-y-0 group-hover:scale-y-100 transition-transform duration-300 origin-bottom"></div>
              </Link>
            </motion.div>

            {/* Enterprise */}
            <motion.div variants={itemVariants} className="bg-white border-3 border-neo-black p-8 flex flex-col shadow-[8px_8px_0_0_#000] hover:-translate-y-2 hover:shadow-[12px_12px_0_0_#000] transition-all duration-300">
              <h3 className="text-4xl font-display font-black mb-2 uppercase">Empire</h3>
              <p className="text-gray-600 font-bold text-lg mb-6">For large organizations</p>
              <div className="text-6xl font-display font-black mb-8">$299<span className="text-2xl text-gray-500 font-bold">/mo</span></div>
              <ul className="space-y-4 mb-8 flex-grow">
                {['Unlimited contacts', 'Custom integrations', 'Dedicated IP', 'SAML SSO', '24/7 Phone support'].map((item, i) => (
                  <li key={i} className="flex items-center font-sans font-bold text-lg">
                    <CheckCircle2 className="text-electric-blue mr-3 flex-shrink-0" size={24} strokeWidth={3} />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/about" className="neo-button-secondary w-full text-xl">Contact Sales</Link>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
