import { Mail, Zap, Users, BarChart3, Star, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Features() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: "spring" as const, stiffness: 100 }
    }
  };

  return (
    <div className="pt-24 min-h-screen bg-off-white">
      <section className="py-24 bg-off-white border-b-3 border-neo-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={containerVariants}
            className="text-center max-w-4xl mx-auto mb-20"
          >
            <motion.div variants={itemVariants} className="neo-badge bg-hot-pink text-white mb-6">Features</motion.div>
            <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-display font-black uppercase mb-6 leading-none">Everything you need <br/>to <span className="text-electric-blue" style={{ textShadow: '4px 4px 0 #000' }}>dominate</span></motion.h1>
            <motion.p variants={itemVariants} className="text-2xl font-sans font-bold text-gray-700 border-l-4 border-neo-black pl-6 text-left">Stop juggling multiple tools. Kognit provides a unified platform for all your marketing automation needs.</motion.p>
          </motion.div>

          <motion.div 
            initial="hidden"
            animate="visible"
            variants={containerVariants}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              { icon: <Mail size={40} strokeWidth={2.5} />, title: "Email Campaigns", desc: "Drag-and-drop builder with high-converting templates.", color: "bg-electric-blue" },
              { icon: <Zap size={40} strokeWidth={2.5} />, title: "Visual Workflows", desc: "If-this-then-that logic made simple and visual.", color: "bg-hot-pink" },
              { icon: <Users size={40} strokeWidth={2.5} />, title: "Deep Segmentation", desc: "Target users based on behavior, not just demographics.", color: "bg-vivid-yellow" },
              { icon: <BarChart3 size={40} strokeWidth={2.5} />, title: "Real-time Analytics", desc: "See exactly what's working and what's not instantly.", color: "bg-green-400" },
              { icon: <Star size={40} strokeWidth={2.5} />, title: "A/B Testing", desc: "Test subject lines, content, and send times.", color: "bg-purple-400" },
              { icon: <CheckCircle2 size={40} strokeWidth={2.5} />, title: "Deliverability", desc: "Dedicated IP options and automated list cleaning.", color: "bg-orange-400" }
            ].map((feature, i) => (
              <motion.div 
                key={i} 
                variants={itemVariants}
                className="neo-card flex flex-col items-start group"
              >
                <div className={`p-4 border-3 border-neo-black ${feature.color} text-neo-black mb-6 shadow-[4px_4px_0_0_#000] group-hover:-rotate-6 transition-transform duration-300`}>
                  {feature.icon}
                </div>
                <h3 className="text-3xl font-display font-black mb-4 uppercase">{feature.title}</h3>
                <p className="font-sans text-xl font-bold text-gray-700 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
    </div>
  );
}
