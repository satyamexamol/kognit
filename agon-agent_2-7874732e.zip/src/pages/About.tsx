import { motion } from 'framer-motion';
import { BookOpen, PenTool, Zap, DollarSign, Users, Target } from 'lucide-react';

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring' as const, stiffness: 100, damping: 15 }
    }
  };

  return (
    <div className="pt-32 pb-32 bg-off-white min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="mb-20 text-center"
        >
          <motion.div variants={itemVariants} className="neo-badge bg-hot-pink text-white mb-6">
            <BookOpen size={16} className="mr-2" strokeWidth={3} /> Our Story
          </motion.div>
          <motion.h1 variants={itemVariants} className="text-6xl md:text-8xl font-display font-black uppercase leading-none mb-8" style={{ textShadow: '4px 4px 0 #0055FF' }}>
            We hate <br/>boring software.
          </motion.h1>
          <motion.div variants={itemVariants} className="h-4 w-48 bg-vivid-yellow border-3 border-neo-black mx-auto shadow-[4px_4px_0_0_#000]"></motion.div>
        </motion.div>

        <div className="prose prose-xl max-w-none font-sans font-bold text-xl space-y-8 text-neo-black">
          <motion.div 
            initial={{ opacity: 0, rotate: -5, scale: 0.9 }}
            whileInView={{ opacity: 1, rotate: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ type: "spring", stiffness: 100 }}
            className="bg-white border-3 border-neo-black p-8 md:p-12 shadow-[12px_12px_0_0_#000] mb-16 relative"
          >
            <div className="absolute -top-6 -right-6 bg-vivid-yellow border-3 border-neo-black p-3 shadow-[4px_4px_0_0_#000] transform rotate-12">
              <Target size={40} strokeWidth={2.5} className="text-neo-black" />
            </div>
            <p className="text-3xl leading-relaxed font-black uppercase font-display mb-0">
              Kognit was born out of frustration. Frustration with clunky interfaces, hidden pricing, and marketing tools that felt like they were built in 1999.
            </p>
          </motion.div>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="leading-relaxed"
          >
            In 2023, our founders (a designer and an engineer who were tired of arguing over email templates) decided to build something different. Something bold, fast, and aggressively functional.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ type: "spring", stiffness: 100 }}
            className="bg-electric-blue text-white border-3 border-neo-black p-8 md:p-12 my-16 shadow-[12px_12px_0_0_#FF0066] -rotate-1"
          >
            <h3 className="text-5xl font-display font-black mb-8 uppercase text-vivid-yellow" style={{ textShadow: '3px 3px 0 #000' }}>Our Manifesto</h3>
            <ul className="space-y-8 list-none pl-0">
              {[
                { num: "1.", title: "Design matters.", desc: "If you use a tool every day, it shouldn't make your eyes bleed.", color: "text-hot-pink", icon: <PenTool size={32} strokeWidth={2.5} /> },
                { num: "2.", title: "Speed is a feature.", desc: "Waiting for a page to load is a crime against productivity.", color: "text-vivid-yellow", icon: <Zap size={32} strokeWidth={2.5} /> },
                { num: "3.", title: "No BS pricing.", desc: "You should know exactly what you're paying for.", color: "text-electric-blue", icon: <DollarSign size={32} strokeWidth={2.5} /> }
              ].map((item, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="flex items-start bg-neo-black p-6 border-3 border-white hover:translate-x-2 transition-transform duration-300"
                >
                  <div className={`flex-shrink-0 ${item.color} mr-6 flex flex-col items-center`}>
                    <span className="font-display font-black text-4xl mb-2">{item.num}</span>
                    {item.icon}
                  </div>
                  <span className="text-2xl mt-1"><strong>{item.title}</strong> {item.desc}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="leading-relaxed"
          >
            Today, Kognit is used by over 10,000 marketers who share our vision. We're a remote-first team spread across 14 countries, united by our love for bold design and clean code.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 2 }}
            viewport={{ once: true }}
            transition={{ type: "spring", stiffness: 200, damping: 10 }}
            className="inline-block bg-vivid-yellow border-3 border-neo-black p-4 shadow-[6px_6px_0_0_#000] mt-8"
          >
            <p className="text-3xl font-display font-black uppercase m-0">We're just getting started. Join us.</p>
          </motion.div>
        </div>

        <div className="mt-32 pt-16 border-t-8 border-neo-black">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-6xl font-display font-black uppercase mb-16 text-center flex items-center justify-center gap-4"
          >
            <Users size={56} className="text-electric-blue" strokeWidth={3} /> The Squad
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { name: 'Sarah', role: 'CEO', color: 'bg-electric-blue', shadow: 'shadow-[8px_8px_0_0_#000]' },
              { name: 'David', role: 'CTO', color: 'bg-hot-pink', shadow: 'shadow-[8px_8px_0_0_#000]' },
              { name: 'Elena', role: 'Head of Product', color: 'bg-vivid-yellow', shadow: 'shadow-[8px_8px_0_0_#000]' },
            ].map((member, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, type: "spring", stiffness: 100 }}
                className="group cursor-pointer"
              >
                <div className={`aspect-square ${member.color} border-4 border-neo-black mb-6 ${member.shadow} group-hover:translate-x-[-4px] group-hover:translate-y-[-4px] group-hover:shadow-[12px_12px_0_0_#000] transition-all duration-300 overflow-hidden relative`}>
                  <div className="absolute inset-0 bg-neo-black opacity-20 mix-blend-overlay z-10 transition-opacity duration-300 group-hover:opacity-0"></div>
                  <img src={`https://i.pravatar.cc/400?img=${i+11}`} alt={member.name} className="w-full h-full object-cover mix-blend-luminosity opacity-90 group-hover:mix-blend-normal group-hover:opacity-100 transition-all duration-500 group-hover:scale-110 relative z-0" />
                </div>
                <div className="bg-white border-3 border-neo-black p-4 text-center shadow-[4px_4px_0_0_#000] transition-transform duration-300 group-hover:-translate-y-1">
                  <h3 className="text-3xl font-display font-black uppercase">{member.name}</h3>
                  <p className="font-sans font-bold text-xl text-gray-600">{member.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
